import torch
import torch.nn.functional as F
from data_loader import MVTecDRAEMTestDataset
from torch.utils.data import DataLoader
import numpy as np
from sklearn.metrics import roc_auc_score, average_precision_score
from model_unet import ReconstructiveSubNetwork, DiscriminativeSubNetwork
import os
from sklearn.metrics import auc
from scipy.ndimage import gaussian_filter
from skimage import measure
import pandas as pd
from numpy import ndarray
import time
import cv2
from statistics import mean


def print_current_performance(auroc, ap, auroc_pixel, ap_pixel, aupro_pixel):
    message = '   '
    log_name = r"train_log1.txt"
    dt = time.gmtime()
    message += str(dt.tm_year) + "-" + str(dt.tm_mon) + "-" + str(dt.tm_mday) + "-" + str(
        dt.tm_hour + 8) + ":" + str(
        dt.tm_min) + ":" + str(dt.tm_sec)
    message += "AUC Image: %.3f###" % auroc
    message += 'AP Image: %.3f###' % ap
    message += 'AUC Pixel: %.3f' % auroc_pixel
    message += 'AP Pixel: %.3f' % ap_pixel
    message += ' AUPro Pixel: %.3f' % aupro_pixel
    with open(log_name, "a") as log_file:
        log_file.write('%s\n' % message)


def compute_pro(masks: ndarray, amaps: ndarray, num_th: int = 200) -> None:
    """Compute the area under the curve of per-region overlaping (PRO) and 0 to 0.3 FPR
    Args:
        category (str): Category of product
        masks (ndarray): All binary masks in test. masks.shape -> (num_test_data, h, w)
        amaps (ndarray): All anomaly maps in test. amaps.shape -> (num_test_data, h, w)
        num_th (int, optional): Number of thresholds
    """

    assert isinstance(amaps, ndarray), "type(amaps) must be ndarray"
    assert isinstance(masks, ndarray), "type(masks) must be ndarray"
    assert amaps.ndim == 3, "amaps.ndim must be 3 (num_test_data, h, w)"
    assert masks.ndim == 3, "masks.ndim must be 3 (num_test_data, h, w)"
    assert amaps.shape == masks.shape, "amaps.shape and masks.shape must be same"
    assert set(masks.flatten()) == {0, 1}, "set(masks.flatten()) must be {0, 1}"
    assert isinstance(num_th, int), "type(num_th) must be int"

    df = pd.DataFrame(columns=["pro", "fpr", "threshold"])
    binary_amaps = np.zeros_like(amaps, dtype=np.bool_)

    min_th = amaps.min()
    max_th = amaps.max()
    delta = (max_th - min_th) / num_th

    for th in np.arange(min_th, max_th, delta):
        binary_amaps[amaps <= th] = 0
        binary_amaps[amaps > th] = 1

        pros = []
        for binary_amap, mask in zip(binary_amaps, masks):
            for region in measure.regionprops(measure.label(mask)):
                axes0_ids = region.coords[:, 0]
                axes1_ids = region.coords[:, 1]
                tp_pixels = binary_amap[axes0_ids, axes1_ids].sum()
                pros.append(tp_pixels / region.area)

        inverse_masks = 1 - masks
        fp_pixels = np.logical_and(inverse_masks, binary_amaps).sum()
        fpr = fp_pixels / inverse_masks.sum()
        df_new_row = pd.DataFrame({"pro": [mean(pros)], "fpr": [fpr], "threshold": [th]})
        df = pd.concat([df, df_new_row])

    # Normalize FPR from 0 ~ 1 to 0 ~ 0.3
    df = df[df["fpr"] < 0.3]
    df["fpr"] = df["fpr"] / df["fpr"].max()

    pro_auc = auc(df["fpr"], df["pro"])
    return pro_auc


def write_results_to_file(run_name, image_auc, pixel_auc, image_ap, pixel_ap, pixel_aupro):
    if not os.path.exists('./outputs/'):
        os.makedirs('./outputs/')

    fin_str = "img_auc," + run_name
    for i in image_auc:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(image_auc), 3))
    fin_str += "\n"
    fin_str += "pixel_auc," + run_name
    for i in pixel_auc:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(pixel_auc), 3))
    fin_str += "\n"
    fin_str += "img_ap," + run_name
    for i in image_ap:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(image_ap), 3))
    fin_str += "\n"
    fin_str += "pixel_ap," + run_name
    for i in pixel_ap:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(pixel_ap), 3))
    fin_str += "\n"
    fin_str += "pixel_aupro," + run_name
    for i in pixel_aupro:
        fin_str += "," + str(np.round(i, 3))
    fin_str += "," + str(np.round(np.mean(pixel_aupro), 3))
    fin_str += "\n"
    fin_str += "--------------------------\n"
    with open("./outputs/results.txt", 'a+') as file:
        file.write(fin_str)


def show_cam_on_image(img, anomaly_map):
    # if anomaly_map.shape != img.shape:
    #    anomaly_map = cv2.applyColorMap(np.uint8(anomaly_map), cv2.COLORMAP_JET)
    cam = np.float32(anomaly_map) / 255 + np.float32(img) / 255
    cam = cam / np.max(cam)
    return np.uint8(255 * cam)


def min_max_norm(image):
    a_min, a_max = image.min(), image.max()
    return (image - a_min) / (a_max - a_min)


def cvt2heatmap(gray):
    heatmap = cv2.applyColorMap(np.uint8(gray), cv2.COLORMAP_JET)
    return heatmap


def test(obj_names, args):
    obj_auroc_pixel_list = []
    obj_aupro_pixel_list = []
    obj_ap_pixel_list = []
    obj_ap_image_list = []
    obj_auroc_image_list = []
    total_gt_pixel_scores = []
    total_pixel_scores = []
    anomaly_score_gt = []
    anomaly_score_prediction = []
    aupro_list = []
    for obj_name in obj_names:
        print(obj_name)
        run_name = 'DRAEM_train_' + str(args.image_size) + "_" + obj_name + "_" + str(args.epochs)
        device = 'cuda' if torch.cuda.is_available() else 'cpu'
        print(device)

        model = ReconstructiveSubNetwork()
        model.load_state_dict(torch.load(os.path.join(args.checkpoint_path, run_name + ".pckl"), map_location='cuda:0'))
        model.to(device)
        model.eval()

        model_seg = DiscriminativeSubNetwork(in_channels=6, out_channels=2)
        model_seg.load_state_dict(
            torch.load(os.path.join(args.checkpoint_path, run_name + "_seg.pckl"), map_location='cuda:0'))
        model_seg.to(device)
        model_seg.eval()

        dataset = MVTecDRAEMTestDataset(args.data_path + obj_name + "/test/",
                                        resize_shape=[args.image_size, args.image_size])
        dataloader = DataLoader(dataset, batch_size=1,
                                shuffle=False, num_workers=0)

        cnt_display = 0
        display_indices = np.random.randint(len(dataloader), size=(30,31))

        for i_batch, sample_batched in enumerate(dataloader):
            gray_batch = sample_batched["image"].to(device)
            is_normal = sample_batched["has_anomaly"].detach().numpy()[0, 0]
            true_mask = sample_batched["mask"]

            gray_rec = model(gray_batch)
            joined_in = torch.cat((gray_rec.detach(), gray_batch), dim=1)
            out_mask = model_seg(joined_in)
            out_mask_sm = torch.softmax(out_mask, dim=1)

            out_mask_cv = out_mask_sm[0, 1, :, :].cpu().detach().numpy()
            out_mask_cv = gaussian_filter(out_mask_cv, sigma=4)

            true_mask[true_mask > 0.5] = 1
            true_mask[true_mask <= 0.5] = 0
            if is_normal.item() != 0:
                aupro_list.append(compute_pro(true_mask.squeeze(0).cpu().detach().numpy().astype(int),
                                              out_mask_cv[np.newaxis, :, :]))

            total_gt_pixel_scores.extend(true_mask.cpu().detach().numpy().astype(int).ravel())
            total_pixel_scores.extend(out_mask_cv.ravel())
            anomaly_score_gt.append(np.max(true_mask.cpu().detach().numpy().astype(int)))
            anomaly_score_prediction.append(np.max(out_mask_cv))

            if i_batch in display_indices:
                t_mask = out_mask_sm[0, 1, :, :].cpu().detach().numpy()
                t_mask = gaussian_filter(t_mask, sigma=4)
                ano_map = min_max_norm(t_mask)
                ano_map = cvt2heatmap(ano_map * 255)
                img = cv2.cvtColor(gray_batch.permute(0, 2, 3, 1).cpu().detach().numpy()[0] * 255, cv2.COLOR_BGR2RGB)
                img = np.uint8(min_max_norm(img) * 255)

                if not os.path.exists('./results_all/' + obj_name + '_' + str(args.epochs)):
                    os.makedirs('./results_all/' + obj_name + '_' + str(args.epochs))

                ano_map = show_cam_on_image(img, ano_map)
                cv2.imwrite('./results_all/' + obj_name + '_' + str(args.epochs) + '/' + str(cnt_display) + '_' + 'ad.png',
                            ano_map)

                gt = true_mask.cpu().detach().numpy().astype(int)[0][0] * 255
                cv2.imwrite('./results_all/' + obj_name + '_' + str(args.epochs) + '/' + str(cnt_display) + '_' + 'gt.png',
                            gt)

                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
                cv2.imwrite('./results_all/' + obj_name + '_' + str(args.epochs) + '/' + str(cnt_display) + '_' + 'org.png',
                            img)

                cnt_display += 1

        auroc = round(roc_auc_score(anomaly_score_gt, anomaly_score_prediction), 3)
        auroc_pixel = round(roc_auc_score(total_gt_pixel_scores, total_pixel_scores), 3)
        ap = round(average_precision_score(anomaly_score_gt, anomaly_score_prediction), 3)
        ap_pixel = round(average_precision_score(total_gt_pixel_scores, total_pixel_scores), 3)
        aupro_pixel = round(np.mean(aupro_list), 3)
        obj_auroc_pixel_list.append(auroc_pixel)
        obj_aupro_pixel_list.append(aupro_pixel)
        obj_auroc_image_list.append(auroc)
        obj_ap_image_list.append(ap)
        obj_ap_pixel_list.append(ap_pixel)
        print(obj_name)
        print("AUC Image:  " + str(auroc))
        print("AP Image:  " + str(ap))
        print("AUC Pixel:  " + str(auroc_pixel))
        print("AP Pixel:  " + str(ap_pixel))
        print("Aupro Pixel:  " + str(aupro_pixel))
        print("==============================")

    print(run_name)
    print("AUC Image mean:  " + str(np.mean(obj_auroc_image_list)))
    print("AP Image mean:  " + str(np.mean(obj_ap_image_list)))
    print("AUC Pixel mean:  " + str(np.mean(obj_auroc_pixel_list)))
    print("AP Pixel mean:  " + str(np.mean(obj_ap_pixel_list)))
    print("AuPro Pixel mean:  " + str(np.mean(obj_aupro_pixel_list)))
    write_results_to_file(run_name, obj_auroc_image_list, obj_auroc_pixel_list, obj_ap_image_list, obj_ap_pixel_list,
                          obj_aupro_pixel_list)


if __name__ == "__main__":

    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument('--obj_id', default=0, type=int)
    parser.add_argument('--data_path', default='E:/database/MVTec/', type=str)
    parser.add_argument('--checkpoint_path', default='./checkpoints/', type=str)
    parser.add_argument('--log_path', default='./logs/', type=str)
    parser.add_argument('--epochs', default=700, type=int)
    parser.add_argument('--image_size', default=256, type=int)

    args = parser.parse_args()

    obj_batch = [['capsule'],
                 ['bottle'],
                 ['carpet'],
                 ['leather'],
                 ['pill'],
                 ['transistor'],
                 ['tile'],
                 ['cable'],
                 ['zipper'],
                 ['toothbrush'],
                 ['metal_nut'],
                 ['hazelnut'],
                 ['screw'],
                 ['grid'],
                 ['wood'],
                 ['blue'],
                 ['red']
                 ]


    picked_classes = obj_batch[int(args.obj_id)]

    test(picked_classes, args)
